import React, { useState } from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';

// ✅ REQUIREMENT: Custom component (HardwareRow) reused multiple times
// ✅ REQUIREMENT: Receives props from parent (ProjectCard)
function HardwareRow({ name, checked, total, joined }) {
  // ✅ REQUIREMENT: useState to track the qty input field
  const [qty, setQty] = useState('');
  // ✅ REQUIREMENT: Custom event handler modifies component state
  const [checkedOut, setCheckedOut] = useState(checked);

  const handleCheckIn = () => {
    const amount = Math.max(0, parseInt(qty) || 0);
    setCheckedOut(prev => Math.min(total, prev + amount));
    setQty('');
  };

  const handleCheckOut = () => {
    const amount = Math.max(0, parseInt(qty) || 0);
    setCheckedOut(prev => Math.max(0, prev - amount));
    setQty('');
  };

  return (
    <Box display="flex" alignItems="center" gap={1} mb={1} flexWrap="wrap">
      {/* Hardware name + count */}
      <Typography variant="body2" sx={{ minWidth: 130, fontWeight: 500 }}>
        {name}: {checkedOut}/{total}
      </Typography>

      {/* ✅ REQUIREMENT: TextField is a MUI component */}
      <TextField
        size="small"
        placeholder="Enter qty"
        value={qty}
        onChange={(e) => setQty(e.target.value)}
        sx={{ width: 100 }}
        type="number"
        disabled={!joined}
      />

      {/* ✅ REQUIREMENT: Button is a MUI component */}
      <Button variant="outlined" size="small" onClick={handleCheckIn} disabled={!joined}>
        Check In
      </Button>

      <Button variant="outlined" size="small" onClick={handleCheckOut} disabled={!joined}>
        Check Out
      </Button>
    </Box>
  );
}

export default HardwareRow;
import React, { useState } from 'react';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import HardwareRow from './HardwareRow';

// ✅ REQUIREMENT: Custom component other than Projects
// ✅ REQUIREMENT: Receives props from parent (Projects)
function ProjectCard({ name, users, hardwareSets }) {
  // ✅ REQUIREMENT: Custom event handler modifies state (joined/not joined)
  const [joined, setJoined] = useState(false);

  const handleJoinLeave = () => {
    setJoined(prev => !prev);
  };

  return (
    <Paper
      elevation={2}
      sx={{
        p: 2,
        mb: 2,
        backgroundColor: joined ? '#f0fff4' : '#fff',
        border: joined ? '1px solid #81c784' : '1px solid #ddd',
      }}
    >
      <Box display="flex" alignItems="flex-start" justifyContent="space-between" gap={2}>

        {/* Left: project name and users */}
        <Box minWidth={200}>
          <Typography variant="h6" fontWeight={600}>{name}</Typography>
          <Typography variant="body2" color="text.secondary">{users}</Typography>
        </Box>

        {/* Middle: hardware rows */}
        {/* ✅ REQUIREMENT: HardwareRow reused multiple times, props passed each time */}
        <Box flex={1}>
          {hardwareSets.map((hw) => (
            <HardwareRow
              key={hw.name}
              name={hw.name}
              checked={hw.checked}
              total={hw.total}
              joined={joined}
            />
          ))}
        </Box>

        {/* Right: Join/Leave button */}
        {/* ✅ REQUIREMENT: Button is a MUI component */}
        <Button
          variant="contained"
          color={joined ? 'success' : 'primary'}
          onClick={handleJoinLeave}
          sx={{ alignSelf: 'center', minWidth: 80 }}
        >
          {joined ? 'Leave' : 'Join'}
        </Button>

      </Box>
    </Paper>
  );
}

export default ProjectCard;